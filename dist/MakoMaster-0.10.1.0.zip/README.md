# MakoMaster

基于 Dalamud 的《最终幻想14》国服“魔光键影”辅助插件，当前为 API 15 测试版。

## 使用

- 加载 `MakoMaster.dll` 后输入 `/makomaster` 打开控制窗口，点击“开始”或“停止”。
- 循环游玩：选中入场 NPC，勾选“循环开局”，填写次数后开始；完成指定局数并退出结算后停止。
- 随机间隔收在默认折叠的“高级设置”，默认每键 30～80 毫秒、每词 500～1200 毫秒。
- **文件保存默认关闭**，每次重新加载都会恢复关闭。高级设置中点击“保存日志”才写入日志和学习记录；再次点击“关闭日志”停止保存，自动输入继续运行。
- 未开启保存时，学习结果仅在本次运行的内存中保留。手动点击“保存设置”可单独保存参数。

## 输入规则

绿色护盾 → 当前可打断读条 → 当前不可打断读条 → 普通词；同级优先处理离画面下方中央更近的词。
整词去标点匹配，候选提前出现就选择；整词只翻下一页，仍找不到则逐字输入。发送后不重试当前题目。
“运动体探知干扰器”和“诅咒视线”在预计读条结束前后各 0.5 秒暂停，结束时间根据读条进度估算。缺少可用进度时无法保证提前半秒，只保留结束后的半秒暂停。

## 在线安装

仓库发布后，在卫月设置的“自定义插件仓库”中添加：

```text
https://raw.githubusercontent.com/DocherPap/MakoMaster/main/repo.json
```

保存并刷新插件列表，搜索 **MakoMaster** 安装。索引和安装包须能公开访问，无需额外网页。
本仓库仅针对 API 15；其他 API 版本需重新适配。仍需实机验证循环菜单、输入法翻页和读条边界。

## 构建与发布

需要 .NET 10 SDK 和对应版本的卫月依赖目录，通过参数或 `DALAMUD_HOME` 指定；项目不包含个人路径和卫月 DLL。

```powershell
dotnet build .\MakoMaster.csproj -c Release -p:DalamudLibPath="卫月依赖目录"
dotnet run --project .\tests\BehaviorTests\BehaviorTests.csproj
pwsh -File .\scripts\Package.ps1 -DalamudLibPath "卫月依赖目录"
```

打包脚本生成 `dist/MakoMaster-版本.zip`、校验文件和 `repo.json`。增加版本时同步修改工程和插件清单中的版本号，重新打包，然后把这些文件提交并推送到 `main`，插件列表即可读取新版本。
`captures/`、个人词库、设置及构建缓存均被排除；只有 `dist/` 下的正式安装 ZIP 会进入 Git。
